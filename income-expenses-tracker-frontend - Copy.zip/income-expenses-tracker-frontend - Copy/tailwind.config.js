/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./src/**/*.{html,js,jsx,ts,tsx}"],
  theme: {
    extend: {
      backgroundColor: {
        yellow1: "#FFFFD5",
        yellow2: "#FFFDD0",
        yellow3: "#FFFFD5",
        hoveryellow: "#FDDA0D",
        apricot: "#ECFFDC",
        lblue: "#F0FFFF",
        lpurple: "#CBC3E3",
        yel: "#EDF283",
        k: "#EDF283",
        ll: "#ADD8E6",
        vio: "#6C3483",
        lwhite: "#F7F9F9",
        grayt: "#F2F3F4",
        maize: "#FBEC5D",
      },
    },
  },
  plugins: [],
};
